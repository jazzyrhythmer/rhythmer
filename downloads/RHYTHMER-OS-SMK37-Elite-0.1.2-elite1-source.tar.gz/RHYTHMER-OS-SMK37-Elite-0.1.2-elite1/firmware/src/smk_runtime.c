/* SPDX-License-Identifier: GPL-3.0-only
 * SMK-37 Pro integration by Jazzy Rhythmer; board input/LED layer by genkigenki.
 * Included after the ordinary UI. All edits use its existing track/step state. */
static smk_pickup_t smk_fader_state;

static void smk_buttons(uint32_t pressed)
{
    if (ui.menu || ui.confirm || name_on()) return;
    if ((pressed & (1u<<SMK_BTN_KNOB_BANK)) && smk_btn_free(SMK_BTN_KNOB_BANK)) {
        smk_pad_mode^=1u; smk_pad_gate=1;
        ui_say("PADS ",smk_pad_mode?"STEPS":"PLAY"); ui.force=1;
    }
    if ((pressed & (1u<<SMK_BTN_FADER_BANK)) && smk_btn_free(SMK_BTN_FADER_BANK)) {
        static const char *const names[4]={"LEVEL","PAN","REVERB","DELAY"};
        smk_fbank=(uint8_t)((smk_fbank+1u)%4u);
        smk_fader_state.valid=smk_fader_state.caught=0;
        ui_say("FADERS ",names[smk_fbank]); ui.force=1;
    }
    if ((pressed & (1u<<SMK_BTN_LEFT)) && smk_btn_free(SMK_BTN_LEFT)) page_go(-1);
    if ((pressed & (1u<<SMK_BTN_RIGHT)) && smk_btn_free(SMK_BTN_RIGHT)) page_go(1);
}

static void smk_pad_steps(void)
{
    static uint16_t prev;
    uint16_t down=0, fresh;
    uint32_t i, len=(uint32_t)clamp(TSEL->p[P_SLEN],1,NSTEP);
    for (i=0;i<16u;i++) if (fm1_in.pad_st[i]&0x80u) down|=(uint16_t)(1u<<i);
    fresh=(uint16_t)(down&~prev); prev=down;
    if (smk_pad_gate && !down) smk_pad_gate=0;
    smk_pad_grid=1; /* physical pad 1 is always top-left, for hits and LEDs */
    smk_pad_separate=(uint8_t)(smk_pad_mode || smk_pad_gate);
    if (!smk_pad_mode || smk_pad_gate || ui.menu || ui.confirm || ui.layer || name_on()) return;
    for (i=0;i<16u;i++) if ((fresh>>i)&1u) {
        uint32_t at=ui.bank*16u+i;
        track_t *t=TSEL;
        if (at>=len) continue;
        if (chain_busy()) { ui_message("STOP SONG TO EDIT"); continue; }
        undo_mark();
        if (drum_track(t)) grid_hit(t,at,ui.lane,2);
        else {
            step_t *s=&t->step[at];
            if (s->time==ST_NOTE && s->n) step_clear(s);
            else {
                step_clear(s);s->time=ST_NOTE;
                s->n=(uint8_t)chord_build(t,last_note,s->note);
                if (t->engine==ENGI_BREAK) { s->n=1;s->note[0]=(uint8_t)i; }
                s->vel=fm1_in.key_vel[SMK_KEY_F3+SMK_WHITE_NOTE[i]];
                if (!s->vel) s->vel=100;
            }
        }
        t->seq_active=1;cursor_set((int32_t)at);ui.force=1;
    }
}

static void smk_pad_picture(void)
{
    uint32_t i,len=(uint32_t)clamp(TSEL->p[P_SLEN],1,NSTEP),phase=0xFFFFFFFFu;
    if (!smk_pad_mode) return;
    if (song.playing) phase=seq_src(TSEL,TSEL->seq_idx);
    for (i=0;i<16u;i++) {
        uint32_t at=ui.bank*16u+i,lv=0;
        if (at<len) {
            const step_t *s=&TSEL->step[at];
            uint32_t on=drum_track(TSEL)?(step_lanes(s)>>ui.lane)&1u:s->time==ST_NOTE&&s->n;
            lv=on?120u:i%4u?0u:10u;
            if (s->time==ST_TIE) lv=45;
            if (at==phase) lv=255;
            if (fm1_in.pad_st[i]&0x80u) lv=255;
        }
        padled_set(i,(uint8_t)lv,(uint8_t)lv,(uint8_t)lv);
    }
}

static void smk_faders_poll(void)
{
    uint32_t i,start=song.sel>=4u?4u:0u,context=smk_fbank*2u+(start!=0);
    if (fm1_in.frames<300u) return;
    for (i=0;i<4u && start+i<NTRK;i++) {
        track_t *t=&trk[start+i];
        int16_t *p=&t->p[smk_fbank==1u?P_PAN:smk_fbank==2u?P_REV:smk_fbank==3u?P_DLY:P_LEVEL];
        int offset=smk_fbank==1u?64:0;
        int v=smk_pickup(&smk_fader_state,(uint8_t)context,i,fm1_in.fader[i],(uint8_t)clamp(*p+offset,0,127));
        if (v>=0 && *p!=v-offset) { *p=(int16_t)(v-offset);ui.force=1; }
    }
}

static void smk_wheels(void)
{
    enum { DEAD = 12, SPAN0 = 80, MOD_LO = 485, MOD_HI = 615 };
    static int32_t pc, plo, phi, mlo, mhi, rest;
    int32_t p = fm1_in.wheel[0], m = fm1_in.wheel[1], d, b, mw;
    if (fm1_in.frames < 300u)                     /* (the readings settle) */
        return;
    if (!pc) {
        pc = p;
        plo = p - SPAN0;
        phi = p + SPAN0;
        mlo = m < MOD_LO ? m : MOD_LO;
        mhi = m > MOD_HI ? m : MOD_HI;
    }
    if (p < plo)
        plo = p;
    if (p > phi)
        phi = p;
    if (m < mlo)
        mlo = m;
    if (m > mhi)
        mhi = m;
    d = p - pc;
    if (d > -DEAD && d < DEAD) {
        b = 0;
        if (++rest > 200) {                        /* resting: the centre follows a slow drift */
            pc += d > 0 ? 1 : d < 0 ? -1 : 0;
            rest = 0;
        }
    } else {
        rest = 0;
        b = d > 0 ? (d - DEAD) * 8191 / (phi - pc - DEAD > 1 ? phi - pc - DEAD : 1)
                  : (d + DEAD) * 8192 / (pc - plo - DEAD > 1 ? pc - plo - DEAD : 1);
        b = clamp(b, -8192, 8191);
    }
    mw = mhi - m <= DEAD ? 0 : (mhi - m - DEAD) * 127 / (mhi - mlo - DEAD > 1 ? mhi - mlo - DEAD : 1);
    smk_bend14 = (int16_t)b;
    smk_modw = (uint8_t)clamp(mw, 0, 127);
}

static void smk_runtime_poll(void)
{
    smk_pad_steps();
    smk_faders_poll();
    smk_wheels();
}
