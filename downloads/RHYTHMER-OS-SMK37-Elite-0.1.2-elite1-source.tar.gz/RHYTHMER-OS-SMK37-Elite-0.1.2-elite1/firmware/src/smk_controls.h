/* SPDX-License-Identifier: GPL-3.0-only
 * SMK-37 control integration by Jazzy Rhythmer. Pure helpers also run in tests. */
#pragma once
#include <stdint.h>
typedef struct {
    uint8_t context, valid, caught, last[4], applied[4];
} smk_pickup_t;
/* Return -1 until the physical fader reaches the currently stored value.
 * An external edit, bank change or track-window change re-arms pickup. */
static int smk_pickup(smk_pickup_t *s, uint8_t context, uint32_t i, uint8_t v, uint8_t current)
{
    uint32_t bit;
    int lo, hi;
    if (i >= 4u || v > 127u || current > 127u) return -1;
    if (s->context != context) { s->context=context; s->valid=s->caught=0; }
    bit=1u<<i;
    if (!(s->valid & bit)) {
        s->valid|=(uint8_t)bit; s->last[i]=v; s->applied[i]=current;
        return -1;
    }
    if ((s->caught & bit) && current != s->applied[i]) s->caught&=(uint8_t)~bit;
    lo=s->last[i]<v?s->last[i]:v; hi=s->last[i]>v?s->last[i]:v;
    if (!(s->caught & bit) && v!=s->last[i] && current>=lo-1 && current<=hi+1)
        s->caught|=(uint8_t)bit;
    s->last[i]=v;
    if (!(s->caught & bit)) return -1;
    s->applied[i]=v;
    return v;
}
static uint32_t smk_outer_logical(uint32_t key)
{
    return key<5u?27u+key:key>=32u&&key<37u?key:0xFFFFFFFFu;
}
static int32_t smk_key_offset(uint32_t logical)
{
    return logical<27u?(int32_t)logical:logical<32u?(int32_t)logical-32:(int32_t)logical-5;
}
