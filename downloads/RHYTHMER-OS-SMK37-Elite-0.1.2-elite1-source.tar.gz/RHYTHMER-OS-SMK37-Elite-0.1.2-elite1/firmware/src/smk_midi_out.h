/* SPDX-License-Identifier: GPL-3.0-only
 * Bounded standalone TRS MIDI output. Jazzy Rhythmer, 2026.
 * One audio-side producer / higher-priority TIMER5 consumer, independent of USB.
 * Publish complete packets only. Realtime bytes may interleave a MIDI message.
 * Overflow schedules CC64/120/123 on all channels, never a truncated note-off.
 * The whole state is in POOL so SMK's small fixed .bss margin stays untouched. */
#pragma once
#include <stdint.h>
#ifndef SMK_MIDI_PUBLISH
#define SMK_MIDI_PUBLISH() __asm__ volatile("" ::: "memory")
#endif
static struct {
    uint32_t queue[64];
    uint8_t rt[16];
    volatile uint16_t w,r;
    volatile uint8_t rw,rr,urgent,panic,reset,muted;
    uint8_t bytes[3],pos,len,busy,wait,failures,fault,panic_step,generation;
    uint32_t sent,dropped,overflows,timeouts;
} smk_midi __attribute__((aligned(4),section(".pool")));
static uint32_t smk_midi_length(uint32_t p)
{
    unsigned c=p&15u,s=(p>>8)&255u,a=(p>>16)&255u,b=p>>24;
    if(c>=8u&&c<=14u) {
        if((s>>4)!=c||a>127u)return 0;
        if(c==12u||c==13u)return 2;
        return b<=127u?3u:0u;
    }
    if(c==2u&&(s==0xF1u||s==0xF3u)&&a<=127u)return 2;
    if(c==3u&&s==0xF2u&&a<=127u&&b<=127u)return 3;
    if(c==5u&&s==0xF6u)return 1;
    if(c==15u&&(s==0xF8u||s==0xFAu||s==0xFBu||s==0xFCu||s==0xFEu||s==0xFFu))return 1;
    return 0; /* Never forward updater/editor SysEx or invalid CIN/status. */
}
static void smk_midi_init(void)
{
    memset(&smk_midi,0,sizeof smk_midi);
    smk_uart_tx_init();
}
static void smk_midi_set_enabled(uint32_t enabled)
{
    smk_midi.muted=(uint8_t)!enabled;
    smk_midi.panic=1;
    SMK_MIDI_PUBLISH();
    smk_midi.reset=1; /* TIMER5 owns UART restart and panic transmission. */
}
static void smk_midi_out_packet(uint32_t p)
{
    uint32_t n=smk_midi_length(p),s=(p>>8)&255u;
    if(!n)return;
    if((p&15u)==15u) {
        if(smk_midi.muted&&s!=0xFCu)return;
        if(smk_midi.fault||smk_midi.reset) {
            if(s==0xFAu||s==0xFBu||s==0xFCu)smk_midi.urgent=(uint8_t)s;
            return;
        }
        uint8_t w=smk_midi.rw;
        if((uint8_t)(w-smk_midi.rr)>=16u) {
            if(s==0xFAu||s==0xFBu||s==0xFCu)smk_midi.urgent=(uint8_t)s;
            else smk_midi.dropped++;
        } else {
            smk_midi.rt[w&15u]=(uint8_t)s;
            SMK_MIDI_PUBLISH();smk_midi.rw=(uint8_t)(w+1u);
        }
        return;
    }
    if(smk_midi.muted||smk_midi.panic||smk_midi.fault||smk_midi.reset){smk_midi.dropped++;return;}
    uint16_t w=smk_midi.w;
    if((uint16_t)(w-smk_midi.r)>=64u) {
        smk_midi.overflows++;smk_midi.dropped++;
        SMK_MIDI_PUBLISH();smk_midi.panic=1;
        return;
    }
    smk_midi.queue[w&63u]=p;
    SMK_MIDI_PUBLISH();smk_midi.w=(uint16_t)(w+1u);
}
static void smk_midi_out_poll(void)
{
    if(smk_midi.reset) {
        smk_uart_tx_restart();
        smk_midi.r=smk_midi.w;smk_midi.rr=smk_midi.rw;
        smk_midi.busy=smk_midi.pos=smk_midi.len=smk_midi.wait=0;
        smk_midi.fault=smk_midi.failures=smk_midi.panic_step=0;
        smk_midi.reset=0;
    }
    if(smk_midi.fault)return;
    if(smk_midi.busy) {
        if(!smk_uart_tx_done()) {
            if(++smk_midi.wait<30u)return;
            smk_midi.timeouts++;smk_midi.wait=0;
            if(++smk_midi.failures>=4u){smk_midi.fault=1;return;}
            smk_uart_tx_restart();
            smk_midi.busy=smk_midi.pos=smk_midi.len=0;
            smk_midi.panic=1;smk_midi.panic_step=0;
        } else {smk_midi.busy=0;smk_midi.wait=smk_midi.failures=0;}
    }
    uint8_t byte;
    if(smk_midi.urgent) {
        byte=smk_midi.urgent;smk_midi.urgent=0;smk_midi.rr=smk_midi.rw;
    } else if(smk_midi.rr!=smk_midi.rw) {
        byte=smk_midi.rt[smk_midi.rr&15u];smk_midi.rr++;
    } else {
        if(smk_midi.pos>=smk_midi.len) {
            smk_midi.pos=smk_midi.len=0;
            if(smk_midi.panic) {
                smk_midi.r=smk_midi.w;
                if(smk_midi.panic_step>=64u){smk_midi.panic=smk_midi.panic_step=0;smk_midi.len=0;smk_midi.generation++;return;}
                unsigned at=smk_midi.panic_step++;
                static const uint8_t cc[4]={64,120,121,123};
                smk_midi.bytes[0]=(uint8_t)(0xB0u+at/4u);
                smk_midi.bytes[1]=cc[at%4u];smk_midi.bytes[2]=0;smk_midi.len=3;
            } else {
                if(smk_midi.r==smk_midi.w)return;
                uint32_t p=smk_midi.queue[smk_midi.r&63u];smk_midi.r++;
                smk_midi.len=(uint8_t)smk_midi_length(p);
                if(!smk_midi.len)return;
                smk_midi.bytes[0]=(uint8_t)(p>>8);smk_midi.bytes[1]=(uint8_t)(p>>16);smk_midi.bytes[2]=(uint8_t)(p>>24);
            }
        }
        byte=smk_midi.bytes[smk_midi.pos++];
    }
    smk_uart_tx_byte(byte);smk_midi.busy=1;smk_midi.sent++;
}
