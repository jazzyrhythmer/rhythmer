/* SPDX-License-Identifier: GPL-3.0-only
 * SMK-37 Pro UART1 TX on PC7. Jazzy Rhythmer, 2026.
 * Register setup follows the stock v016 analysis documented by genkigenki:
 * github.com/genkigenki/fm1-to-smk37/docs/01-hardware.md, section 9.
 * No RX, DMA or UART interrupt; a TIMER5 poll sends one byte without waiting. */
#pragma once
#include <stdint.h>
#include "fm1_gpio.h"
#ifndef SMK_UART_REG
#define SMK_UART_REG(a) (*(volatile uint32_t *)(a))
#endif
#ifndef SMK_UART_BARRIER
#define SMK_UART_BARRIER() __asm__ volatile("csync" ::: "memory")
#endif
static void smk_uart_tx_restart(void)
{
    SMK_UART_REG(0x12100u)=0x3400u;
    SMK_UART_REG(0x12104u)=0;
    SMK_UART_REG(0x12108u)=383u;
    SMK_UART_BARRIER();
    SMK_UART_REG(0x12100u)=0x3401u;
}
static void smk_uart_tx_init(void)
{
    SMK_UART_REG(0x10010u)=(SMK_UART_REG(0x10010u)&~(3u<<10))|(1u<<10);
    SMK_UART_REG(0x51028u)=(SMK_UART_REG(0x51028u)&~(0x80u|(15u<<20)))|(1u<<20);
    FM1_PR(FM1_PC,FM1_PU)|=1u<<7;
    FM1_PR(FM1_PC,FM1_PD)|=1u<<7;
    FM1_PR(FM1_PC,FM1_OUT)&=~(1u<<7);
    FM1_PR(FM1_PC,FM1_DIR)&=~(1u<<7);
    FM1_PR(FM1_PC,FM1_DIE)|=1u<<7;
    smk_uart_tx_restart();
}
static int smk_uart_tx_done(void) { return (SMK_UART_REG(0x12100u)&0x8000u)!=0; }
static void smk_uart_tx_byte(uint8_t b)
{
    SMK_UART_REG(0x12100u)|=0x2000u;
    SMK_UART_REG(0x1210Cu)=b;
    SMK_UART_BARRIER();
}
