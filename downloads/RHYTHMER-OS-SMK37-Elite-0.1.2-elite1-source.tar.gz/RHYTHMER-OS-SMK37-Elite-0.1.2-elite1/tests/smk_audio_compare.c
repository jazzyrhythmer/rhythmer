/* SPDX-License-Identifier: GPL-3.0-only. Exact DSP parity across board builds. */
#define main unused_hostsim_main
#include "hostsim.c"
#undef main
int main(void) {
 unsigned tested=0;
 for(unsigned e=0;e<NENGINES;e++) {
  if(!eng_ok(e)||e==ENGI_EMPTY||e==ENGI_BREAK)continue;
  for(unsigned p=0;p<ENGINES[e]->npresets;p++) {
   host_tracks_init();for(unsigned t=0;t<NTRK;t++)trk[t].p[P_LEVEL]=0;
   track_t *t=&trk[0];host_preset(t,e,p);t->p[P_LEVEL]=104;memset(t->v,0,sizeof t->v);
   const engine_t *en=ENGINES[e];voice_t *v=&t->v[0];v->active=v->gate=1;v->note=60;v->vel=112;v->env_out=32767;v->env=0x7fffffffu;
   if(en->block)en->block(t);if(en->note_on)en->note_on(t,v);
   vmod_t m={0};m.inc=pitch_inc(60*16);m.pitch16=60*16;m.amp0=m.amp1=24576;m.shape=16384;m.envq15=32767;
   uint64_t hash=UINT64_C(1469598103934665603),energy=0;unsigned peak=0;
   for(unsigned b=0;b<180;b++) {int32_t out[CTL]={0};if(en->block)en->block(t);en->render(t,v,out,CTL,&m);for(unsigned k=0;k<CTL;k++){uint32_t x=(uint32_t)out[k];for(unsigned j=0;j<4;j++){hash^=(x>>(j*8))&255;hash*=UINT64_C(1099511628211);}unsigned a=out[k]<0?-(int64_t)out[k]:out[k];energy+=a;if(a>peak)peak=a;}}
   printf("%u %u %016llx %u %llu\n",e,p,(unsigned long long)hash,peak,(unsigned long long)energy);tested++;
  }
 }
 fprintf(stderr,"DSP parity renders: %u presets (Break banks separately validated by loader tests)\n",tested);return !tested;
}
