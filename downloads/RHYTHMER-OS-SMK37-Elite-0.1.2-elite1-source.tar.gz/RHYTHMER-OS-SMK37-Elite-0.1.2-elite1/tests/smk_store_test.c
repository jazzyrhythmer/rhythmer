/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BOARD_SMK37 1
#include "../firmware/hal/fm1_flash_map.h"
static uint8_t nor[0x100000], saved[0x100000], expected[23][3840];
static int cut=-1, writes;
static void ok(int value,const char *what){if(!value){fprintf(stderr,"FAIL %s writes=%d cut=%d\n",what,writes,cut);exit(1);}}
static int st_read(uint32_t p,void *d,uint32_t n){if(p>sizeof nor||n>sizeof nor-p)return -1;memcpy(d,nor+p,n);return 0;}
static int one(void){if(cut>=0&&writes++==cut)return -9;return 0;}
static int st_erase(uint32_t p){uint32_t i;ok(!(p&4095)&&FL_STORE_OK(p,4096)&&!FL_PROTECTED(p,4096),"erase guard");for(i=0;i<4096;i++){if(one())return -9;nor[p+i]=255;}return 0;}
static int st_prog(uint32_t p,const void *s,uint32_t n){const uint8_t *b=s;uint32_t i;ok(n&&n<=256&&(p&255)+n<=256&&FL_STORE_OK(p,n)&&!FL_PROTECTED(p,n),"program guard");for(i=0;i<n;i++){if(one())return -9;ok((nor[p+i]&b[i])==b[i],"NOR programming");nor[p+i]&=b[i];}return 0;}
#define __attribute__(x)
#include "../firmware/src/storage.c"
#undef __attribute__
static void check_all(void){uint32_t i;uint8_t b[3840];for(i=0;i<OBJ_COUNT;i++){ok(st_load(i,b,sizeof b)==sizeof b,"load every logical object");ok(!memcmp(b,expected[i],sizeof b),"object retained");}}
static void protected_equal(const uint8_t *b){uint32_t i;for(i=0;i<sizeof nor;i++)if(i<FL_DATA_LO||i>=FL_DATA_HI)ok(nor[i]==b[i],"unrelated flash unchanged");}
int main(void){
 uint32_t i,j;uint8_t b[3840],next[3840];
 memset(nor,0xA5,sizeof nor);memset(nor+FL_DATA_LO,255,FL_DATA_HI-FL_DATA_LO);memcpy(saved,nor,sizeof nor);
 for(i=0;i<31u;i++) {
  memcpy(nor,saved,sizeof nor);writes=0;cut=(int)(i*4096u+100u);smk_store_owner();cut=-1;
  ok(!smk_store_owner(),"owner initialization resumes after interrupted erase");protected_equal(saved);
 }
 for(i=0;i<16u;i++) {
  memcpy(nor,saved,sizeof nor);writes=0;cut=(int)(30u*4096u+i);smk_store_owner();cut=-1;
  ok(!smk_store_owner(),"owner commit resumes after interrupted tag");protected_equal(saved);
 }
 memcpy(nor,saved,sizeof nor);
 ok(!smk_store_owner(),"initialize owner");protected_equal(saved);
 for(i=0;i<OBJ_COUNT;i++){for(j=0;j<3840;j++)expected[i][j]=(uint8_t)(i*17u+j*11u);ok(!st_save(i,expected[i],3840),"initial save");}
 memset(nor+SMK_BANK_HOME,0x39,4096);memset(nor+SMK_BANK_STAGE,0x68,4096);
 for(i=0;i<400;i++){uint32_t obj=i%OBJ_COUNT;expected[obj][i%3840]^=(uint8_t)(i+1);ok(!st_save(obj,expected[obj],3840),"rotating save");check_all();}
 ok(nor[SMK_BANK_HOME]==0x39&&nor[SMK_BANK_STAGE]==0x68,"bank reservations retained");
 protected_equal(saved);memcpy(saved,nor,sizeof nor);memset(next,0x5A,sizeof next);
 for(cut=0;cut<=7968;cut++){
  int rc,old,newer;memcpy(nor,saved,sizeof nor);writes=0;
  rc=st_save(3,next,sizeof next);cut=-cut-2;
  ok(st_load(3,b,sizeof b)==sizeof b,"power-cut recovery");old=!memcmp(b,expected[3],sizeof b);newer=!memcmp(b,next,sizeof b);ok(old||newer,"atomic old or new");
  for(i=0;i<OBJ_COUNT;i++)if(i!=3){ok(st_load(i,b,sizeof b)==sizeof b,"other object after cut");ok(!memcmp(b,expected[i],sizeof b),"no collateral write");}
  cut=-cut-2;
  if(!rc)ok(newer,"successful save persists");
 }
 cut=-1;memcpy(nor,saved,sizeof nor);check_all();protected_equal(saved);
 for(i=0;i<0x100000;i+=4096){int safe=i>=FL_DATA_LO&&i<FL_DATA_HI||i>=FL_SMP_LO&&i<FL_SMP_HI||i>=FL_OTA_LO&&i<FL_OTA_HI||i==FL_STOCKTAG_LO;ok(!!FL_GUARD(i,4096)==safe,"flash allow-list exhaustive sectors");}
 ok(!FL_GUARD(0xFFFFFFFFu,256)&&!FL_GUARD(0xBFFFFu,2)&&!FL_GUARD(0xC1FFFu,2)&&!FL_GUARD(0xF3FFFu,2),"overflow and crossing rejected");
 puts("SMK_STORE_PASS: 23 full objects, 400 GC rotations, 7969 byte-cut saves, 47 owner-init interruptions, unrelated flash and banks retained");return 0;
}
