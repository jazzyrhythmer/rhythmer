/* SPDX-License-Identifier: GPL-3.0-only */
#define BOARD_SMK37 1
#define UI_TEST_NO_MAIN 1
#include "ui_test.c"
static void must(int ok,const char *s) { if(!ok){fprintf(stderr,"FAIL %s\n",s);exit(1);} }
static int gated(track_t *t) { int n=0;for(unsigned i=0;i<NVOICE;i++)n+=t->v[i].active&&t->v[i].gate;return n; }
static void setup(void) {
 ui_power_on();fm1_in.keys=fm1_in.notes=kb_prev=0;kb_boot_hold=0;kb_asleep=0;song.grid=0;kb_mask=perf_mask=0;
 for(unsigned i=0;i<NTRK;i++){trk[i].p[P_AHOLD]=trk[i].p[P_AMODE]=trk[i].p[P_CHRD]=trk[i].p[P_SCALE]=0;trk[i].p[P_TRANS]=0;trk[i].p[P_VOICE]=V_POLY;trk[i].p[P_SUS]=127;track_defaults_steps(&trk[i]);}
 song.playing=0;song.octave=0;ui.menu=ui.confirm=ui.layer=0;nm.kind=0;smk_pad_mode=smk_pad_gate=0;fm1_in.frames=400;
}
static void physical(unsigned k,int on,unsigned vel) {
 fm1_in.keys=on?(UINT64_C(1)<<k):0;fm1_in.notes=on&&k>=5&&k<32?1u<<(k-5):0;fm1_in.key_vel[k]=vel;keyboard_block();
}
#include "smk_audit_cases.h"
int main(void) {
 unsigned i;setup();
 for(i=0;i<37;i++) {
  unsigned logical=i<5?27+i:i<32?i-5:i;
  physical(i,1,30+i);must(kb_note[logical]==48+i,"37 keys map C3-C6");must(kb_sn[logical]==1,"single keyboard note");
  int got=0;for(unsigned v=0;v<NVOICE;v++)if(trk[0].v[v].active&&trk[0].v[v].gate&&trk[0].v[v].note==48+i){must(trk[0].v[v].vel==30+i,"key velocity reaches sound engine");got=1;}
  must(got,"key starts real voice");physical(i,0,0);must(!gated(&trk[0]),"key release ends gate");
 }
 physical(36,1,95);song.sel=1;physical(36,0,0);must(!gated(&trk[0])&&!gated(&trk[1]),"outer note release follows original track");
 setup();trk[0].p[P_CHRD]=1;physical(0,1,93);must(kb_sn[27]>1,"outer keys use chord builder");physical(0,0,0);must(!gated(&trk[0]),"outer chord releases all notes");
 setup();trk[0].engine=trk[0].eng_req=ENGI_DRUM;ui.lane=2;trk[0].p[P_SLEN]=32;ui.bank=1;
 smk_buttons(1u<<SMK_BTN_KNOB_BANK);must(smk_pad_mode&&smk_pad_gate,"pad mode guards held pads");smk_pad_steps();
 for(i=0;i<16;i++) {fm1_in.pad_st[i]=128;smk_pad_steps();must((step_lanes(&trk[0].step[16+i])>>2)&1,"every pad edits matching step and lane");fm1_in.pad_st[i]=0;smk_pad_steps();}
 must(!fm1_in.notes,"step pads never generate key notes");ui_leds();smk_pad_picture();
 for(i=0;i<16;i++)must(host_pad_rgb[i][0]&&host_pad_rgb[i][0]==host_pad_rgb[i][1]&&host_pad_rgb[i][1]==host_pad_rgb[i][2],"matching white step LEDs");
 fm1_in.pad_st[11]=128;smk_pad_steps();must(!((step_lanes(&trk[0].step[27])>>2)&1),"pad 12 toggles step 28 off");
 smk_buttons(1u<<SMK_BTN_KNOB_BANK);smk_pad_steps();must(smk_pad_gate&&smk_pad_separate,"switching to play waits for release");fm1_in.pad_st[11]=0;smk_pad_steps();must(!smk_pad_gate&&!smk_pad_separate,"play reopens after release");
 setup();smk_fbank=0;memset(&smk_fader_state,0,sizeof smk_fader_state);for(i=0;i<4;i++){fm1_in.fader[i]=0;trk[i].p[P_LEVEL]=100;}
 smk_faders_poll();for(i=0;i<4;i++)must(trk[i].p[P_LEVEL]==100,"no fader jump on load");
 for(i=0;i<4;i++)fm1_in.fader[i]=110;smk_faders_poll();for(i=0;i<4;i++)must(trk[i].p[P_LEVEL]==110,"four faders select tracks 1-4");
 song.sel=4;trk[4].p[P_LEVEL]=90;trk[5].p[P_LEVEL]=95;smk_faders_poll();must(trk[4].p[P_LEVEL]==90&&trk[5].p[P_LEVEL]==95,"track 5-6 window rearms pickup");
 fm1_in.fader[0]=80;fm1_in.fader[1]=80;smk_faders_poll();must(trk[4].p[P_LEVEL]==80&&trk[5].p[P_LEVEL]==80&&trk[0].p[P_LEVEL]==110,"upper track window isolated");
 ui.menu=1;unsigned bank=smk_fbank;smk_buttons(1u<<SMK_BTN_FADER_BANK);must(smk_fbank==bank,"modal menu retains controls");

 setup();smk_midi_init();usb.config=0;mo_lvl=MO_KEYS;
 uint32_t usb_w=mo_w;physical(7,1,100);must(smk_midi.w==1&&mo_w==usb_w,"TRS key output works without USB");
 for(i=0;i<8;i++)smk_midi_out_poll();must(smk_midi.sent==3,"TRS note-on drains without USB");
 song.sel=1;physical(7,0,0);for(i=0;i<8;i++)smk_midi_out_poll();must(smk_midi.sent==6,"TRS note-off follows original owner across track change");
 usb.config=1;uint16_t trs_w=smk_midi.w;midi_out_event(0x90u<<8|65u<<16|100u<<24|9u);must(mo_w==usb_w+1u&&smk_midi.w==trs_w+1u,"USB and TRS receive the same note independently");usb.config=0;
 mo_lvl=MO_OFF;mo_last=MO_KEYS;mo_block(CTL);must(smk_midi.muted&&smk_midi.reset,"existing MIDI OUT OFF resets TRS safely");

 smk_midi_init();mo_lvl=MO_KEYS;song.sel=0;smk_bend14=1234;smk_modw=72;smk_wheels_block();
 uint16_t wheel_w=smk_midi.w;must(wheel_w==2,"wheel bend and modulation reach TRS");
 song.sel=1;smk_wheels_block();must(smk_midi.w==wheel_w+4,"track change resets old MIDI channel and sends current wheels");
 must((smk_midi.queue[wheel_w&63]&0xFFFFFF00u)==(0xE0u<<8|64u<<24),"old channel pitch bend centered");
 must((smk_midi.queue[(wheel_w+1)&63]&0xFFFFFF00u)==(0xB0u<<8|1u<<16),"old channel modulation reset");
 wheel_w=smk_midi.w;mo_lvl=MO_OFF;smk_bend14=2345;smk_modw=83;smk_wheels_block();must(smk_midi.w==wheel_w,"MIDI OFF suppresses wheel transmission");
 mo_lvl=MO_KEYS;smk_midi.generation++;smk_wheels_block();must(smk_midi.w==wheel_w+2,"panic completion refreshes wheel values once");
 wheel_w=smk_midi.w;smk_wheels_block();must(smk_midi.w==wheel_w,"unchanged wheels do not flood MIDI");

 setup();press(B_PLAY);must(transport_req==1,"physical SEQ PLAY starts transport");
 transport_req=0;song.playing=1;press(B_PLAY);must(transport_req==2,"physical SEQ PLAY stops running transport");
 setup();press(B_REC);must(transport_req==1,"physical SEQ REC starts live recording");transport_req=0;song.playing=1;press(B_PLAY);must(transport_req==2,"PLAY stops REC-started transport");
 setup();ui.menu=1;song.playing=1;press(B_PLAY);must(transport_req==2,"PLAY stops while menu is open");
 smk_audit_cases();
 puts("SMK_RUNTIME_PASS: 37 real key voices/velocity/release, chord and track ownership, 16 step pads/LEDs, held-mode guard, faders and modal controls");return 0;
}
