# SMK-37 Elite — private device test

JAZZY OS and RHYTHMER OS are separate packages. Install only one at a time.
This bundle is a test candidate. A physical Elite installation and recovery
have yet to be verified. Back up existing data before changing firmware.

Unzip the bundle, open Terminal in the extracted directory and run:

```sh
python3 -m http.server 8765 --bind 127.0.0.1
```

In desktop Chrome or Edge, use one of these pages:

- JAZZY Elite: http://127.0.0.1:8765/jazzy/installer/?board=smk37&model=elite
- RHYTHMER Elite: http://127.0.0.1:8765/rhythmer/installer/?board=smk37&model=elite

Confirm that both the keyboard label and installer say **SMK-37 Elite**.
Connect only the test keyboard and keep power and USB connected.
The installer accepts the matching identity and package checksum. A
mismatched model or an unknown interrupted update is rejected before transfer.

After reboot, check 37 keys and their velocity, 16 pads and their LEDs,
all encoders and faders, Play/Stop, audio, TRS MIDI OUT, sample playback
and project save/reload. Record the initial and final device identities.

Use the manufacturer's **Elite V016** entry for a return to factory software,
following the matching model's official recovery instructions. Never use the
Pro factory package on an Elite.
https://www.sincoaudio.com/product?id=smk-37-elite
https://open.m-vave.com/smk37-workbench
